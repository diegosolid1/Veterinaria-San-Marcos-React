# Veterinaria San Marcos – Segunda entrega (React)

Migración del sitio de la primera entrega (HTML + CSS + JS) a **React + Vite**, manteniendo el diseño original (`App.css`).

```bash
npm install
npm run dev     # http://localhost:5173
npm test        # pruebas unitarias con Vitest
```

**Cuenta de prueba:** `admin@duocuc.cl` / `admin123` (también sirve una cuenta creada en "Crea Tu Cuenta").
> Sin backend: la sesión en `localStorage` es solo para la demostración académica.

## Páginas (`src/views`, con react-router-dom)

`/` Index · `/productos` · `/producto/:id` · `/login` · `/registro` · `/carrito` · `/perfil` (privada) · `/admin` (privada) · `*` Error 404

## Estructura (Atomic Design)

```
src/
├── components/
│   ├── atoms/        Boton, Precio
│   ├── molecules/    CampoFormulario, BotonFavorito, TarjetaProducto, TarjetaHorizontal, FiltroProductos
│   ├── organisms/    Header, Footer, Carrusel, Presentacion, GaleriaProductos, ListaCarrito, ResumenCompra,
│   │                 FormularioLogin, FormularioRegistro, FormularioProducto, TablaProductos, DatosPerfil
│   └── templates/    Layout, RutaPrivada
├── views/            las 9 páginas (vistas)
├── context/          TiendaContext.jsx (estados compartidos)
├── hooks/            useFormulario.js (datos y errores de los formularios)
├── utils/            tienda.js (carrito, filtros, favoritos, CRUD, sesión), validaciones.js
├── data/             productos.js, usuarios.js
└── tests/            validaciones.test.js, tienda.test.js
```
