
import { createContext, useContext, useEffect, useState } from 'react'
import productosIniciales from '../data/productos'
import usuariosFijos from '../data/usuarios'
import imagenGenerica from '../assets/img/producto-generico.svg'
import {
  agregarAlCarrito,
  cambiarCantidad,
  quitarDelCarrito,
  calcularTotal,
  alternarFavorito,
  agregarProducto,
  editarProducto,
  eliminarProducto,
  buscarUsuario
} from '../utils/tienda'

// Datos compartidos por varias páginas: tema, carrito, favoritos, productos y sesión.
const TiendaContext = createContext(null)
export const useTienda = () => useContext(TiendaContext)

const leer = (clave, valorInicial) => {
  try {
    return JSON.parse(localStorage.getItem(clave)) ?? valorInicial
  } catch {
    return valorInicial
  }
}
const guardar = (clave, valor) => localStorage.setItem(clave, JSON.stringify(valor))

export function TiendaProvider({ children }) {
  // ---------- ESTADOS (useState) ----------
  const [tema, setTema] = useState(() => leer('tema', 'claro'))
  const [carrito, setCarrito] = useState(() => leer('carrito', []))
  const [favoritos, setFavoritos] = useState(() => leer('favoritos', []))
  const [productos, setProductos] = useState(productosIniciales) // CRUD en memoria
  const [usuario, setUsuario] = useState(() => leer('sesion', null))

  // El tema se guarda en localStorage y se aplica como clase del <body>
  useEffect(() => {
    guardar('tema', tema)
    document.body.classList.toggle('tema-oscuro', tema === 'oscuro')
  }, [tema])

  // El carrito y los favoritos también se guardan en localStorage
  useEffect(() => guardar('carrito', carrito), [carrito])
  useEffect(() => guardar('favoritos', favoritos), [favoritos])

  // ---------- Carrito ----------
  const total = calcularTotal(carrito, productos)
  const cantidadEnCarrito = carrito.reduce((suma, item) => suma + item.cantidad, 0)

  // ---------- Panel de Control: los productos nuevos usan una imagen genérica ----------
  const crearProducto = (datos) =>
    setProductos((actual) => agregarProducto(actual, { ...datos, precio: Number(datos.precio), imagen: imagenGenerica }))

  const actualizarProducto = (id, datos) =>
    setProductos((actual) => editarProducto(actual, id, { ...datos, precio: Number(datos.precio) }))

  const borrarProducto = (id) => {
    setProductos((actual) => eliminarProducto(actual, id))
    setCarrito((actual) => quitarDelCarrito(actual, id))
    setFavoritos((actual) => actual.filter((f) => f !== id))
  }

  // ---------- Sesión (la sesión vive en localStorage) ----------
  // Devuelve true si las credenciales son correctas.
  const iniciarSesion = (correo, clave) => {
    const encontrado = buscarUsuario(correo, clave, [...usuariosFijos, ...leer('usuarios', [])])
    if (!encontrado) return false
    const sesion = { ...encontrado, clave: undefined } // la contraseña no se guarda en la sesión
    guardar('sesion', sesion)
    setUsuario(sesion)
    return true
  }

  // Devuelve false si el correo ya estaba registrado.
  const registrarUsuario = (datos) => {
    const registrados = leer('usuarios', [])
    const usado = [...usuariosFijos, ...registrados].some((u) => u.correo.toLowerCase() === datos.correo.trim().toLowerCase())
    if (usado) return false
    guardar('usuarios', [...registrados, { ...datos, confirmar: undefined, rol: 'cliente' }])
    return true
  }

  const cerrarSesion = () => {
    localStorage.removeItem('sesion')
    setUsuario(null)
  }

  const valor = {
    tema,
    alternarTema: () => setTema(tema === 'claro' ? 'oscuro' : 'claro'),
    productos,
    crearProducto,
    actualizarProducto,
    borrarProducto,
    carrito,
    total,
    cantidadEnCarrito,
    agregarProductoAlCarrito: (id) => setCarrito((actual) => agregarAlCarrito(actual, id)),
    cambiarCantidadProducto: (id, cambio) => setCarrito((actual) => cambiarCantidad(actual, id, cambio)),
    quitarProductoDelCarrito: (id) => setCarrito((actual) => quitarDelCarrito(actual, id)),
    vaciarCarrito: () => setCarrito([]),
    favoritos,
    alternarProductoFavorito: (id) => setFavoritos((actual) => alternarFavorito(actual, id)),
    usuario,
    iniciarSesion,
    registrarUsuario,
    cerrarSesion
  }

  return <TiendaContext.Provider value={valor}>{children}</TiendaContext.Provider>
}
