import { useState } from 'react'

// maneja los datos y errores de un formulario (lo usan Login, Registro y Producto).
function useFormulario(inicial, validar) {
  const [datos, setDatos] = useState(inicial)
  const [errores, setErrores] = useState({})

  const campo = (nombre) => ({
    valor: datos[nombre],
    error: errores[nombre],
    onChange: (e) => setDatos({ ...datos, [nombre]: e.target.value })
  })

  // valida al enviar, si hay errores los muestra, si no ejecuta la acción
  const enviar = (accion) => (e) => {
    e.preventDefault()
    const encontrados = validar(datos)
    setErrores(encontrados)
    if (Object.keys(encontrados).length === 0) accion(datos)
  }

  const limpiar = () => setDatos(inicial)

  return { campo, enviar, limpiar }
}

export default useFormulario
