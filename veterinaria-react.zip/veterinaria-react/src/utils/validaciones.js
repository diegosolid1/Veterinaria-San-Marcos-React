// Validaciones de los formularios 
// Cada función devuelve '' si el dato está bien, o el mensaje de error si está mal.

const REGEX_CORREO = /^[a-zA-Z0-9._%+-]+@(?:gmail\.com|hotmail\.com|outlook\.com|yahoo\.com|live\.com|duocuc\.cl)$/i
const REGEX_LETRAS = /^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+$/
const REGEX_TELEFONO = /^\+56\d{9}$/

export const validarObligatorio = (valor, mensaje) => (String(valor).trim() === '' ? mensaje : '')

export function validarCorreo(correo) {
  if (correo.trim() === '') return 'Por favor, no olvides ingresar tu correo electrónico.'
  if (!REGEX_CORREO.test(correo.trim())) return 'Ingresa un correo válido (ej. gmail.com, outlook.com, yahoo.com, hotmail.com, duocuc.cl).'
  return ''
}

export function validarClave(clave) {
  if (clave === '') return 'Por favor, ingresa tu contraseña.'
  return clave.length < 6 ? 'La contraseña debe tener al menos 6 caracteres.' : ''
}

export function validarSoloLetras(valor, etiqueta) {
  if (valor.trim() === '') return `Por favor, ingresa el ${etiqueta}.`
  return REGEX_LETRAS.test(valor.trim()) ? '' : `El ${etiqueta} debe contener solamente letras.`
}

export function validarTelefono(telefono) {
  if (telefono.trim() === '') return 'Por favor, ingresa tu teléfono.'
  return REGEX_TELEFONO.test(telefono.trim()) ? '' : 'El teléfono debe comenzar con +56 seguido de 9 dígitos (ej: +56912345678).'
}

export function validarNacimiento(fecha, hoy = new Date()) {
  if (fecha === '') return 'Por favor, ingresa la fecha de nacimiento.'
  return fecha > hoy.toISOString().slice(0, 10) ? 'La fecha de nacimiento no puede ser futura.' : ''
}

function validarPrecio(precio) {
  if (precio === '') return 'Por favor, ingresa el precio.'
  return Number(precio) <= 0 ? 'El precio debe ser mayor a 0.' : ''
}

// Deja solo los campos con error. Si el objeto queda vacío, el formulario es válido.
const soloErrores = (errores) => Object.fromEntries(Object.entries(errores).filter(([, mensaje]) => mensaje !== ''))

export const validarLogin = (d) => soloErrores({ correo: validarCorreo(d.correo), clave: validarClave(d.clave) })

export const validarRegistro = (d) =>
  soloErrores({
    nombre: validarSoloLetras(d.nombre, 'nombre'),
    apellido: validarSoloLetras(d.apellido, 'apellido'),
    telefono: validarTelefono(d.telefono),
    correo: validarCorreo(d.correo),
    clave: validarClave(d.clave),
    confirmar: d.confirmar === '' ? 'Por favor, reingresa la contraseña.' : d.clave !== d.confirmar ? 'Las contraseñas no coinciden.' : '',
    // Campos propios de la veterinaria: datos de la mascota (paciente)
    nombreMascota: validarObligatorio(d.nombreMascota, 'Por favor, ingresa el nombre de la mascota.'),
    especie: validarObligatorio(d.especie, 'Por favor, selecciona una especie de la lista.'),
    sexo: validarObligatorio(d.sexo, 'Por favor, selecciona el sexo de la mascota.'),
    nacimiento: validarNacimiento(d.nacimiento)
  })

// Formulario del Panel de Control: categoría y especie son campos propios de la veterinaria
export const validarProducto = (d) =>
  soloErrores({
    nombre: validarObligatorio(d.nombre, 'Por favor, ingresa el nombre del producto.'),
    categoria: validarObligatorio(d.categoria, 'Por favor, selecciona una categoría.'),
    especie: validarObligatorio(d.especie, 'Por favor, selecciona la especie.'),
    precio: validarPrecio(d.precio),
    descripcion: validarObligatorio(d.descripcion, 'Por favor, ingresa una descripción.')
  })
