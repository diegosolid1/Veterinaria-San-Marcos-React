// Toda la lógica de la tienda (devuelven datos nuevos, no modifican los originales).

export const formatearPrecio = (valor) => '$' + Number(valor).toLocaleString('es-CL')

// ----- Carrito: lista como [{ id: 1, cantidad: 2 }] -----
export function agregarAlCarrito(carrito, id) {
  if (!carrito.some((item) => item.id === id)) return [...carrito, { id, cantidad: 1 }]
  return carrito.map((item) => (item.id === id ? { ...item, cantidad: item.cantidad + 1 } : item))
}

// cambio = +1 o -1. Si la cantidad llega a 0 el producto sale del carrito.
export function cambiarCantidad(carrito, id, cambio) {
  return carrito
    .map((item) => (item.id === id ? { ...item, cantidad: item.cantidad + cambio } : item))
    .filter((item) => item.cantidad > 0)
}

export const quitarDelCarrito = (carrito, id) => carrito.filter((item) => item.id !== id)

export function calcularTotal(carrito, productos) {
  return carrito.reduce((suma, item) => {
    const producto = productos.find((p) => p.id === item.id)
    return suma + (producto ? producto.precio * item.cantidad : 0)
  }, 0)
}

// ----- Catálogo: filtros y favoritos -----
// filtros = { texto: '', categoria: '', soloFavoritos: false }
export function filtrarProductos(productos, filtros, favoritos) {
  return productos.filter(
    (p) =>
      p.nombre.toLowerCase().includes(filtros.texto.toLowerCase()) &&
      (filtros.categoria === '' || p.categoria === filtros.categoria) &&
      (!filtros.soloFavoritos || favoritos.includes(p.id))
  )
}

export function alternarFavorito(favoritos, id) {
  return favoritos.includes(id) ? favoritos.filter((f) => f !== id) : [...favoritos, id]
}

// ----- CRUD en memoria (Panel de Control) -----
export function agregarProducto(productos, nuevo) {
  const siguienteId = Math.max(0, ...productos.map((p) => p.id)) + 1
  return [...productos, { ...nuevo, id: siguienteId }]
}

export const editarProducto = (productos, id, cambios) =>
  productos.map((p) => (p.id === id ? { ...p, ...cambios } : p))

export const eliminarProducto = (productos, id) => productos.filter((p) => p.id !== id)

// ----- Sesión -----
// Devuelve el usuario o null si el correo o la contraseña no coinciden.
export function buscarUsuario(correo, clave, usuarios) {
  const buscado = correo.trim().toLowerCase()
  return usuarios.find((u) => u.correo.toLowerCase() === buscado && u.clave === clave) || null
}
