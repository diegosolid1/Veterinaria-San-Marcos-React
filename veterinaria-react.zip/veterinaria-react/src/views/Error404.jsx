import { Link } from 'react-router-dom'

function Error404() {
  return (
    <main>
      <section className="presentacion">
        <h2>Error 404</h2>
        <p>La página que buscas no existe.</p>
        <Link to="/" className="boton">Volver al inicio</Link>
      </section>
    </main>
  )
}

export default Error404
