import ListaCarrito from '../components/organisms/ListaCarrito'
import ResumenCompra from '../components/organisms/ResumenCompra'

//  2 columnas: productos a la izquierda y resumen de compra a la derecha
function Carrito() {
  return (
    <main className="contenedor-detalle">
      <ListaCarrito />
      <ResumenCompra />
    </main>
  )
}

export default Carrito
