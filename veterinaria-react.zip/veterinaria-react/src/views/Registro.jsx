import FormularioRegistro from '../components/organisms/FormularioRegistro'

function Registro() {
  return (
    <main>
      <FormularioRegistro />
    </main>
  )
}

export default Registro
