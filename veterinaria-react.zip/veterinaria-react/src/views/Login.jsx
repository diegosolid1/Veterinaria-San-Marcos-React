import FormularioLogin from '../components/organisms/FormularioLogin'

function Login() {
  return (
    <main>
      <FormularioLogin />
    </main>
  )
}

export default Login
