import { Link, useParams } from 'react-router-dom'
import TarjetaHorizontal from '../components/molecules/TarjetaHorizontal'
import BotonFavorito from '../components/molecules/BotonFavorito'
import Boton from '../components/atoms/Boton'
import Error404 from './Error404'
import { useTienda } from '../context/TiendaContext'

function Producto() {
  const { id } = useParams() // el id viene de la URL: /producto/3
  const { productos, agregarProductoAlCarrito } = useTienda()
  const producto = productos.find((p) => p.id === Number(id))

  if (!producto) return <Error404 />

  return (
    <main className="contenedor-detalle">
      <section className="columna-productos">
        <h2>Detalle del Producto</h2>

        <TarjetaHorizontal producto={producto}>
          <p className="datos-producto">
            <strong>Categoría:</strong> {producto.categoria} | <strong>Especie:</strong> {producto.especie}
          </p>
          <div className="acciones-detalle">
            <Boton clase="boton-ver" onClick={() => agregarProductoAlCarrito(producto.id)}>Agregar al carrito</Boton>
            <BotonFavorito id={producto.id} />
          </div>
        </TarjetaHorizontal>

        <Link to="/productos" className="enlace-volver">← Volver al catálogo</Link>
      </section>
    </main>
  )
}

export default Producto
