import { useState } from 'react'
import Carrusel from '../components/organisms/Carrusel'
import FiltroProductos from '../components/molecules/FiltroProductos'
import GaleriaProductos from '../components/organisms/GaleriaProductos'
import { useTienda } from '../context/TiendaContext'
import { filtrarProductos } from '../utils/tienda'

function Productos() {
  const { productos, favoritos } = useTienda()

  // Filtros dinámicos: cada vez que cambia el estado, la lista se vuelve a calcular
  const [filtros, setFiltros] = useState({ texto: '', categoria: '', soloFavoritos: false })

  return (
    <main id="Web">
      <section id="Principal">
        <Carrusel />
        <FiltroProductos filtros={filtros} onCambiar={setFiltros} />
        <GaleriaProductos productos={filtrarProductos(productos, filtros, favoritos)} />
      </section>
    </main>
  )
}

export default Productos
