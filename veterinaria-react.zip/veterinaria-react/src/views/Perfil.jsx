import DatosPerfil from '../components/organisms/DatosPerfil'
import { useTienda } from '../context/TiendaContext'

function Perfil() {
  const { usuario } = useTienda()

  return (
    <main>
      <DatosPerfil usuario={usuario} />
    </main>
  )
}

export default Perfil
