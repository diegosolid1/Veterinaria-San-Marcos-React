import { useState } from 'react'
import FormularioProducto from '../components/organisms/FormularioProducto'
import TablaProductos from '../components/organisms/TablaProductos'
import { useTienda } from '../context/TiendaContext'

// Panel de Control: agrega, edita y elimina productos en memoria 
function Admin() {
  const { productos, crearProducto, actualizarProducto, borrarProducto } = useTienda()
  const [productoEditar, setProductoEditar] = useState(null) // null = estamos agregando
  const [mensaje, setMensaje] = useState('')

  const guardar = (datos) => {
    if (productoEditar) {
      actualizarProducto(productoEditar.id, datos)
      setProductoEditar(null)
      setMensaje('Producto actualizado correctamente.')
    } else {
      crearProducto(datos)
      setMensaje('Producto agregado al catálogo.')
    }
  }

  const eliminar = (producto) => {
    if (window.confirm(`¿Eliminar "${producto.nombre}" del catálogo?`)) {
      borrarProducto(producto.id)
      if (productoEditar?.id === producto.id) setProductoEditar(null)
      setMensaje('Producto eliminado.')
    }
  }

  return (
    <main className="contenedor-detalle contenedor-admin">
      <section className="columna-productos">
        <h2>Panel de Control</h2>
        {mensaje && <div className="exito-msg">{mensaje}</div>}
        <TablaProductos productos={productos} onEditar={setProductoEditar} onEliminar={eliminar} />
      </section>

      <aside className="columna-resumen">
        {/* "key" reinicia el formulario cuando cambia el producto que se edita */}
        <FormularioProducto
          key={productoEditar ? productoEditar.id : 'nuevo'}
          productoEditar={productoEditar}
          onGuardar={guardar}
          onCancelar={() => setProductoEditar(null)}
        />
      </aside>
    </main>
  )
}

export default Admin
