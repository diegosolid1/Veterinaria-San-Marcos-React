import Presentacion from '../components/organisms/Presentacion'
import banner from '../assets/img/bannerIndex.png'

function Index() {
  return (
    <>
      <div className="contenedor-banner">
        <img src={banner} alt="Banner de la página" className="banner-img" />
      </div>
      <main>
        <Presentacion />
      </main>
    </>
  )
}

export default Index
