import { Routes, Route } from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.min.css'
import './App.css'
import Layout from './components/templates/Layout'
import RutaPrivada from './components/templates/RutaPrivada'
import Index from './views/Index'
import Productos from './views/Productos'
import Producto from './views/Producto'
import Login from './views/Login'
import Registro from './views/Registro'
import Carrito from './views/Carrito'
import Perfil from './views/Perfil'
import Admin from './views/Admin'
import Error404 from './views/Error404'

function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Index />} />
        <Route path="/productos" element={<Productos />} />
        <Route path="/producto/:id" element={<Producto />} />
        <Route path="/login" element={<Login />} />
        <Route path="/registro" element={<Registro />} />
        <Route path="/carrito" element={<Carrito />} />

        {/* Rutas privadas: solo con sesión iniciada */}
        <Route path="/perfil" element={<RutaPrivada><Perfil /></RutaPrivada>} />
        <Route path="/admin" element={<RutaPrivada><Admin /></RutaPrivada>} />

        <Route path="*" element={<Error404 />} />
      </Route>
    </Routes>
  )
}

export default App
