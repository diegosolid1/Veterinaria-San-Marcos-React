import { describe, it, expect } from 'vitest'
import { validarCorreo, validarTelefono, validarRegistro, validarProducto } from '../utils/validaciones'

describe('Validaciones de formularios', () => {
  it('acepta un correo con dominio permitido', () => {
    // Arrange
    const correo = 'cliente@gmail.com'
    // Act
    const resultado = validarCorreo(correo)
    // Assert
    expect(resultado).toBe('')
  })

  it('rechaza un teléfono sin el prefijo +56', () => {
    // Arrange
    const telefono = '912345678'
    // Act
    const resultado = validarTelefono(telefono)
    // Assert
    expect(resultado).not.toBe('')
  })

  it('un registro completo, con datos de la mascota, no tiene errores', () => {
    // Arrange
    const datos = {
      nombre: 'Camila', apellido: 'Rojas', telefono: '+56912345678', correo: 'camila@gmail.com',
      clave: 'abcdef', confirmar: 'abcdef',
      nombreMascota: 'Firulais', especie: 'Perro', sexo: 'Macho', nacimiento: '2020-05-10'
    }
    // Act
    const errores = validarRegistro(datos)
    // Assert
    expect(errores).toEqual({})
  })

  it('el formulario de producto rechaza un precio negativo', () => {
    // Arrange
    const datos = { nombre: 'Collar', categoria: 'Alimento', especie: 'Perro', precio: '-5', descripcion: 'Collar' }
    // Act
    const errores = validarProducto(datos)
    // Assert
    expect(errores.precio).toBe('El precio debe ser mayor a 0.')
  })
})
