import { describe, it, expect } from 'vitest'
import {
  agregarAlCarrito,
  cambiarCantidad,
  calcularTotal,
  filtrarProductos,
  alternarFavorito,
  agregarProducto,
  editarProducto,
  eliminarProducto,
  buscarUsuario
} from '../utils/tienda'

const productos = [
  { id: 1, nombre: 'Vitalcan Perro Adulto', categoria: 'Alimento', precio: 10000 },
  { id: 2, nombre: 'Advantix 10-25 Kg', categoria: 'Antiparasitario', precio: 5000 },
  { id: 3, nombre: 'Consulta Veterinaria', categoria: 'Servicio', precio: 9000 }
]
const sinFiltros = { texto: '', categoria: '', soloFavoritos: false }
const usuarios = [{ correo: 'admin@duocuc.cl', clave: 'admin123', rol: 'admin' }]

describe('Carrito de compras', () => {
  it('agrega un producto nuevo con cantidad 1', () => {
    // Arrange
    const carrito = []
    // Act
    const resultado = agregarAlCarrito(carrito, 1)
    // Assert
    expect(resultado).toEqual([{ id: 1, cantidad: 1 }])
  })

  it('suma 1 a la cantidad si el producto ya estaba en el carrito', () => {
    // Arrange
    const carrito = [{ id: 1, cantidad: 2 }]
    // Act
    const resultado = agregarAlCarrito(carrito, 1)
    // Assert
    expect(resultado).toEqual([{ id: 1, cantidad: 3 }])
  })

  it('saca el producto del carrito cuando la cantidad llega a 0', () => {
    // Arrange
    const carrito = [{ id: 1, cantidad: 1 }]
    // Act
    const resultado = cambiarCantidad(carrito, 1, -1)
    // Assert
    expect(resultado).toEqual([])
  })

  it('calcula el total multiplicando precio por cantidad', () => {
    // Arrange
    const carrito = [{ id: 1, cantidad: 2 }, { id: 2, cantidad: 3 }]
    // Act
    const total = calcularTotal(carrito, productos)
    // Assert
    expect(total).toBe(35000)
  })
})

describe('Catálogo: filtros, favoritos y CRUD en memoria', () => {
  it('filtra por texto sin importar mayúsculas', () => {
    // Arrange
    const filtros = { ...sinFiltros, texto: 'advantix' }
    // Act
    const resultado = filtrarProductos(productos, filtros, [])
    // Assert
    expect(resultado).toEqual([productos[1]])
  })

  it('con "solo favoritos" muestra únicamente los productos marcados', () => {
    // Arrange
    const filtros = { ...sinFiltros, soloFavoritos: true }
    // Act
    const resultado = filtrarProductos(productos, filtros, [3])
    // Assert
    expect(resultado).toEqual([productos[2]])
  })

  it('agrega un favorito y lo quita al repetir la acción', () => {
    // Arrange
    const favoritos = []
    // Act
    const conFavorito = alternarFavorito(favoritos, 2)
    const sinFavorito = alternarFavorito(conFavorito, 2)
    // Assert
    expect(conFavorito).toEqual([2])
    expect(sinFavorito).toEqual([])
  })

  it('agrega un producto nuevo con el siguiente id', () => {
    // Arrange
    const nuevo = { nombre: 'Collar antipulgas', categoria: 'Antiparasitario', precio: 5000 }
    // Act
    const resultado = agregarProducto(productos, nuevo)
    // Assert
    expect(resultado).toHaveLength(4)
    expect(resultado[3].id).toBe(4)
  })

  it('edita el precio de un producto sin tocar los demás', () => {
    // Arrange
    const cambios = { precio: 12000 }
    // Act
    const resultado = editarProducto(productos, 2, cambios)
    // Assert
    expect(resultado[1].precio).toBe(12000)
    expect(resultado[0]).toEqual(productos[0])
  })

  it('elimina un producto del catálogo', () => {
    // Arrange
    const id = 1
    // Act
    const resultado = eliminarProducto(productos, id)
    // Assert
    expect(resultado.some((p) => p.id === id)).toBe(false)
    expect(resultado).toHaveLength(2)
  })
})

describe('Inicio de sesión', () => {
  it('encuentra al usuario cuando correo y contraseña son correctos', () => {
    // Arrange
    const correo = 'admin@duocuc.cl'
    // Act
    const usuario = buscarUsuario(correo, 'admin123', usuarios)
    // Assert
    expect(usuario.rol).toBe('admin')
  })

  it('devuelve null cuando la contraseña es incorrecta', () => {
    // Arrange
    const correo = 'admin@duocuc.cl'
    // Act
    const usuario = buscarUsuario(correo, 'otraClave', usuarios)
    // Assert
    expect(usuario).toBeNull()
  })
})
