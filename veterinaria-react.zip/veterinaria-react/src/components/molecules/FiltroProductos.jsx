//barra de filtros del catálogo (no guarda nada: recibe los filtros y avisa cuando cambian)
import { Form } from 'react-bootstrap'
import { categorias } from '../../data/productos'

function FiltroProductos({ filtros, onCambiar }) {
  const cambiar = (campo, valor) => onCambiar({ ...filtros, [campo]: valor })

  return (
    <Form className="filtros" onSubmit={(e) => e.preventDefault()}>
      <Form.Control
        type="text"
        placeholder="Buscar producto..."
        value={filtros.texto}
        onChange={(e) => cambiar('texto', e.target.value)}
        aria-label="Buscar producto"
      />

      <Form.Select value={filtros.categoria} onChange={(e) => cambiar('categoria', e.target.value)} aria-label="Filtrar por categoría">
        <option value="">Todas las categorías</option>
        {categorias.map((categoria) => (
          <option key={categoria} value={categoria}>{categoria}</option>
        ))}
      </Form.Select>

      <Form.Check
        type="checkbox"
        id="solo-favoritos"
        label="Solo favoritos"
        checked={filtros.soloFavoritos}
        onChange={(e) => cambiar('soloFavoritos', e.target.checked)}
      />
    </Form>
  )
}

export default FiltroProductos
