// tarjeta horizontal (imagen + datos). Los botones llegan como children,
//la tarjeta sirve el detalle del producto y en el carrito.
import Precio from '../atoms/Precio'

function TarjetaHorizontal({ producto, children }) {
  return (
    <article className="tarjeta-horizontal">
      <img src={producto.imagen} alt={producto.nombre} className="imagen-producto" />

      <div className="info-producto">
        <h3>{producto.nombre}</h3>
        <p className="descripcion">{producto.descripcion}</p>
        <Precio valor={producto.precio} />
        {children}
      </div>
    </article>
  )
}

export default TarjetaHorizontal
