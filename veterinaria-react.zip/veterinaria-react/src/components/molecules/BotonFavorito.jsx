// corazón para marcar o quitar un producto de favoritos 
import { useTienda } from '../../context/TiendaContext'

function BotonFavorito({ id }) {
  const { favoritos, alternarProductoFavorito } = useTienda()
  const esFavorito = favoritos.includes(id)

  return (
    <button
      type="button"
      className={esFavorito ? 'boton-favorito activo' : 'boton-favorito'}
      onClick={() => alternarProductoFavorito(id)}
      aria-label={esFavorito ? 'Quitar de favoritos' : 'Agregar a favoritos'}
    >
      {esFavorito ? '♥' : '♡'}
    </button>
  )
}

export default BotonFavorito
