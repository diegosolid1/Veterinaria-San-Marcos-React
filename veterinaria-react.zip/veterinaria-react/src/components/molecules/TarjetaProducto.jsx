// tarjeta del catálogo (imagen + nombre + botones de ver, carrito y favorito)
import { Link } from 'react-router-dom'
import Boton from '../atoms/Boton'
import BotonFavorito from './BotonFavorito'
import { useTienda } from '../../context/TiendaContext'

function TarjetaProducto({ producto }) {
  const { agregarProductoAlCarrito } = useTienda()

  return (
    <article className="tarjeta">
      <div className="espacio-imagen">
        <img src={producto.imagen} alt={producto.nombre} />
      </div>
      <p>{producto.nombre}</p>

      <Link to={`/producto/${producto.id}`} className="boton boton-ver">
        {producto.categoria === 'Servicio' ? 'Ver Servicios' : 'Ver producto'}
      </Link>

      <div className="acciones-tarjeta">
        <Boton clase="boton-ver" onClick={() => agregarProductoAlCarrito(producto.id)}>Agregar al carrito</Boton>
        <BotonFavorito id={producto.id} />
      </div>
    </article>
  )
}

export default TarjetaProducto
