// etiqueta + campo + mensaje de error (React Bootstrap: "isInvalid" pinta el campo en rojo).

import { Form } from 'react-bootstrap'

function CampoFormulario({ id, etiqueta, tipo = 'text', opciones, valor, onChange, error, ...resto }) {
  return (
    <Form.Group className="campo" controlId={id}>
      <Form.Label>{etiqueta}</Form.Label>

      {tipo === 'select' ? (
        <Form.Select value={valor} onChange={onChange} isInvalid={!!error}>
          <option value="">Seleccione una opción</option>
          {opciones.map((opcion) => (
            <option key={opcion} value={opcion}>{opcion}</option>
          ))}
        </Form.Select>
      ) : (
        <Form.Control
          as={tipo === 'textarea' ? 'textarea' : 'input'}
          rows={tipo === 'textarea' ? 3 : undefined}
          type={tipo === 'textarea' ? undefined : tipo}
          value={valor}
          onChange={onChange}
          isInvalid={!!error}
          {...resto}
        />
      )}

      <Form.Control.Feedback type="invalid">{error}</Form.Control.Feedback>
    </Form.Group>
  )
}

export default CampoFormulario
