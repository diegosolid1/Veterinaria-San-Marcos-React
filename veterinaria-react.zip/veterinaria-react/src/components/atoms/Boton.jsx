//botón con el estilo de la veterinaria 
function Boton({ children, tipo = 'button', clase = 'boton', ...resto }) {
  return (
    <button type={tipo} className={clase} {...resto}>
      {children}
    </button>
  )
}

export default Boton
