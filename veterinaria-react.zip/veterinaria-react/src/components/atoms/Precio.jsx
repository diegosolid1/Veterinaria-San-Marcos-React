//precio con formato chileno
import { formatearPrecio } from '../../utils/tienda'

function Precio({ valor }) {
  return <p className="precio">{formatearPrecio(valor)}</p>
}

export default Precio
