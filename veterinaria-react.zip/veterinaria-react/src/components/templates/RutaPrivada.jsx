// plantilla, protege una página. Sin sesión en localStorage redirige al login.
import { Navigate } from 'react-router-dom'
import { useTienda } from '../../context/TiendaContext'

function RutaPrivada({ children }) {
  const { usuario } = useTienda()
  return usuario === null ? <Navigate to="/login" replace /> : children
}

export default RutaPrivada
