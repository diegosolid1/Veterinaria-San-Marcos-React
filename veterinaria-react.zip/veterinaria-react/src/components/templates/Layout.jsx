// plantilla, todas las páginas llevan el Header arriba y el Footer abajo.
// <Outlet /> es donde React Router dibuja la página de la ruta actual.
import { Outlet } from 'react-router-dom'
import Header from '../organisms/Header'
import Footer from '../organisms/Footer'

function Layout() {
  return (
    <>
      <Header />
      <Outlet />
      <Footer />
    </>
  )
}

export default Layout
