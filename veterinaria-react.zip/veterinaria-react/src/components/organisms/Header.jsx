//título, enlaces de navegación (izquierda) y de usuario (derecha), con el botón de tema
import { Link } from 'react-router-dom'
import { useTienda } from '../../context/TiendaContext'

function Header() {
  const { usuario, cerrarSesion, cantidadEnCarrito, tema, alternarTema } = useTienda()

  return (
    <header>
      <h1>Veterinaria San Marcos</h1>
      <nav id="menu-principal">
        <ul className="nav-links">
          <li><Link to="/">Inicio</Link></li>
          <li><Link to="/productos">Productos</Link></li>
        </ul>

        <ul className="user-links">
          {usuario === null ? (
            <>
              <li><Link to="/registro">Crea Tu Cuenta</Link></li>
              <li><Link to="/login">Ingresa</Link></li>
            </>
          ) : (
            <>
              <li><Link to="/perfil">Mi Perfil</Link></li>
              <li><Link to="/admin">Panel de Control</Link></li>
              <li><Link to="/" onClick={cerrarSesion}>Cerrar Sesión</Link></li>
            </>
          )}
          <li><Link to="/carrito">Mis Compras ({cantidadEnCarrito})</Link></li>
          <li>
            <button type="button" className="boton-tema" onClick={alternarTema}>
              {tema === 'claro' ? '🌙 Tema oscuro' : '☀️ Tema claro'}
            </button>
          </li>
        </ul>
      </nav>
    </header>
  )
}

export default Header
