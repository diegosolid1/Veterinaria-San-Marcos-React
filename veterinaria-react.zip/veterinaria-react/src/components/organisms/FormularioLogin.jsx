//formulario de inicio de sesión (valida y compara con las credenciales)
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Form } from 'react-bootstrap'
import CampoFormulario from '../molecules/CampoFormulario'
import Boton from '../atoms/Boton'
import useFormulario from '../../hooks/useFormulario'
import { useTienda } from '../../context/TiendaContext'
import { validarLogin } from '../../utils/validaciones'

function FormularioLogin() {
  const { iniciarSesion } = useTienda()
  const navegar = useNavigate()
  const [errorGeneral, setErrorGeneral] = useState('')
  const { campo, enviar } = useFormulario({ correo: '', clave: '' }, validarLogin)

  const ingresar = ({ correo, clave }) => {
    if (iniciarSesion(correo, clave)) navegar('/perfil')
    else setErrorGeneral('Correo o contraseña incorrectos.')
  }

  return (
    <Form className="formulario" onSubmit={enviar(ingresar)} noValidate>
      <h2>Iniciar Sesión</h2>
      {errorGeneral && <div className="error-msg">{errorGeneral}</div>}

      <CampoFormulario id="loginCorreo" etiqueta="Correo Electrónico:" tipo="email" placeholder="Ingresa tu correo" {...campo('correo')} />
      <CampoFormulario id="loginClave" etiqueta="Contraseña:" tipo="password" placeholder="Ingresa tu contraseña" {...campo('clave')} />

      <Boton tipo="submit">Ingresar</Boton>
      <p>¿No tienes cuenta? <Link to="/registro">Regístrate aquí</Link></p>
    </Form>
  )
}

export default FormularioLogin
