//banner de la página de productos, cambia de imagen cada 4 segundos 
import { useEffect, useState } from 'react'
import banner1 from '../../assets/img/Banner1.png'
import banner2 from '../../assets/img/Banner2.png'
import banner3 from '../../assets/img/Banner3.png'

const banners = [banner1, banner2, banner3]

function Carrusel() {
  const [indice, setIndice] = useState(0)

  useEffect(() => {
    const temporizador = setInterval(() => setIndice((actual) => (actual + 1) % banners.length), 4000)
    return () => clearInterval(temporizador)
  }, [])

  return (
    <div id="banner-carrusel">
      {banners.map((imagen, i) => (
        <img
          key={imagen}
          src={imagen}
          alt={`Veterinaria San Marcos ${i + 1}`}
          className={i === indice ? 'imagen-banner activa' : 'imagen-banner'}
        />
      ))}
    </div>
  )
}

export default Carrusel
