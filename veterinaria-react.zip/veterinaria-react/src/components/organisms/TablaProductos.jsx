//tabla del Panel de Control con todos los productos 
import Boton from '../atoms/Boton'
import { formatearPrecio } from '../../utils/tienda'

function TablaProductos({ productos, onEditar, onEliminar }) {
  return (
    <div className="tabla-contenedor">
      <table className="tabla-productos">
        <thead>
          <tr>
            <th>Imagen</th><th>Nombre</th><th>Categoría</th><th>Especie</th><th>Precio</th><th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {productos.map((producto) => (
            <tr key={producto.id}>
              <td><img src={producto.imagen} alt={producto.nombre} className="miniatura" /></td>
              <td>{producto.nombre}</td>
              <td>{producto.categoria}</td>
              <td>{producto.especie}</td>
              <td>{formatearPrecio(producto.precio)}</td>
              <td className="acciones-tabla">
                <Boton clase="boton-ver" onClick={() => onEditar(producto)}>Editar</Boton>
                <Boton clase="boton-ver" onClick={() => onEliminar(producto)}>Eliminar</Boton>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default TablaProductos
