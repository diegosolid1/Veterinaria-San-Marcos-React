//formulario del Panel de Control para agregar o editar un producto 
import { Form } from 'react-bootstrap'
import CampoFormulario from '../molecules/CampoFormulario'
import Boton from '../atoms/Boton'
import useFormulario from '../../hooks/useFormulario'
import { categorias, especies } from '../../data/productos'
import { validarProducto } from '../../utils/validaciones'

const productoVacio = { nombre: '', categoria: '', especie: '', precio: '', descripcion: '' }

function FormularioProducto({ productoEditar, onGuardar, onCancelar }) {
  const inicial = productoEditar ? { ...productoEditar, precio: String(productoEditar.precio) } : productoVacio
  const { campo, enviar, limpiar } = useFormulario(inicial, validarProducto)

  const guardar = (datos) => {
    onGuardar(datos)
    if (!productoEditar) limpiar()
  }

  return (
    <Form className="formulario" onSubmit={enviar(guardar)} noValidate>
      <h2>{productoEditar ? 'Editar producto' : 'Agregar producto'}</h2>

      <CampoFormulario id="prodNombre" etiqueta="Nombre:" placeholder="Nombre del producto o servicio" {...campo('nombre')} />
      <CampoFormulario id="prodCategoria" etiqueta="Categoría:" tipo="select" opciones={categorias} {...campo('categoria')} />
      <CampoFormulario id="prodEspecie" etiqueta="Especie a la que va dirigido:" tipo="select" opciones={especies} {...campo('especie')} />
      <CampoFormulario id="prodPrecio" etiqueta="Precio (CLP):" tipo="number" min="1" placeholder="Ej: 9990" {...campo('precio')} />
      <CampoFormulario id="prodDescripcion" etiqueta="Descripción:" tipo="textarea" placeholder="Describe el producto" {...campo('descripcion')} />

      <p className="nota-imagen">Los productos nuevos usan una imagen genérica.</p>
      <Boton tipo="submit">{productoEditar ? 'Guardar cambios' : 'Agregar producto'}</Boton>
      {productoEditar && <Boton clase="boton boton-secundario" onClick={onCancelar}>Cancelar</Boton>}
    </Form>
  )
}

export default FormularioProducto
