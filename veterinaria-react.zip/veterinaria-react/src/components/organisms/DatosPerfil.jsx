//datos de la persona con sesión iniciada y de su mascota 
const Dato = ({ etiqueta, valor }) => <p className="dato"><strong>{etiqueta}:</strong> {valor}</p>

function DatosPerfil({ usuario }) {
  return (
    <div className="formulario">
      <h2>Mi Perfil</h2>

      <fieldset>
        <legend>Datos del Dueño</legend>
        <Dato etiqueta="Nombre" valor={`${usuario.nombre} ${usuario.apellido}`} />
        <Dato etiqueta="Correo" valor={usuario.correo} />
        <Dato etiqueta="Teléfono" valor={usuario.telefono} />
        <Dato etiqueta="Tipo de cuenta" valor={usuario.rol === 'admin' ? 'Administrador' : 'Cliente'} />
      </fieldset>

      {usuario.nombreMascota && (
        <fieldset>
          <legend>Datos del Paciente (Mascota)</legend>
          <Dato etiqueta="Nombre" valor={usuario.nombreMascota} />
          <Dato etiqueta="Especie" valor={usuario.especie} />
          <Dato etiqueta="Sexo" valor={usuario.sexo} />
          <Dato etiqueta="Fecha de nacimiento" valor={usuario.nacimiento} />
        </fieldset>
      )}
    </div>
  )
}

export default DatosPerfil
