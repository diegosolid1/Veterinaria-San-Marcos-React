// registro con datos del dueño y datos de la mascota
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Form } from 'react-bootstrap'
import CampoFormulario from '../molecules/CampoFormulario'
import Boton from '../atoms/Boton'
import useFormulario from '../../hooks/useFormulario'
import { useTienda } from '../../context/TiendaContext'
import { validarRegistro } from '../../utils/validaciones'

const datosVacios = {
  nombre: '', apellido: '', telefono: '', correo: '', clave: '', confirmar: '',
  nombreMascota: '', especie: '', sexo: '', nacimiento: ''
}

// Cada campo: nombre del dato, etiqueta, tipo, placeholder u opciones
const camposDueno = [
  ['nombre', 'Nombre:', 'text', 'Ingresa tu nombre'],
  ['apellido', 'Apellido:', 'text', 'Ingresa tu apellido'],
  ['telefono', 'Teléfono:', 'tel', 'Ej: +56912345678'],
  ['correo', 'Correo Electrónico:', 'email', 'Ingresa tu correo'],
  ['clave', 'Contraseña:', 'password', 'Ingresa tu contraseña'],
  ['confirmar', 'Confirmar Contraseña:', 'password', 'Reingresa tu contraseña']
]

const camposMascota = [
  ['nombreMascota', 'Nombre de la mascota:', 'text', 'Ingresa el nombre de la mascota'],
  ['especie', 'Especie:', 'select', ['Perro', 'Gato', 'Conejo', 'Ave']],
  ['sexo', 'Sexo:', 'select', ['Macho', 'Hembra']],
  ['nacimiento', 'Fecha de Nacimiento:', 'date']
]

function FormularioRegistro() {
  const { registrarUsuario } = useTienda()
  const navegar = useNavigate()
  const [errorGeneral, setErrorGeneral] = useState('')
  const { campo, enviar } = useFormulario(datosVacios, validarRegistro)

  const registrar = (datos) => {
    if (!registrarUsuario(datos)) {
      setErrorGeneral('Ese correo ya está registrado. Intenta iniciar sesión.')
      return
    }
    alert('¡Registro completado con éxito!')
    navegar('/login')
  }

  const dibujar = ([nombre, etiqueta, tipo, extra]) => (
    <CampoFormulario
      key={nombre}
      id={`reg-${nombre}`}
      etiqueta={etiqueta}
      tipo={tipo}
      opciones={tipo === 'select' ? extra : undefined}
      placeholder={tipo === 'select' ? undefined : extra}
      {...campo(nombre)}
    />
  )

  return (
    <Form className="formulario" onSubmit={enviar(registrar)} noValidate>
      {errorGeneral && <div className="error-msg">{errorGeneral}</div>}

      <fieldset>
        <legend>Datos del Dueño</legend>
        {camposDueno.map(dibujar)}
      </fieldset>

      <fieldset>
        <legend>Datos del Paciente (Mascota)</legend>
        {camposMascota.map(dibujar)}
      </fieldset>

      <Boton tipo="submit">Completar Registro</Boton>
    </Form>
  )
}

export default FormularioRegistro
