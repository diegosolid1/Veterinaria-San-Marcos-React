//cuadro Resumen de Compra con el total y el botón Finalizar Compra
import { Link } from 'react-router-dom'
import Boton from '../atoms/Boton'
import { useTienda } from '../../context/TiendaContext'
import { formatearPrecio } from '../../utils/tienda'

function ResumenCompra() {
  const { total, vaciarCarrito } = useTienda()

  const finalizarCompra = () => {
    if (total === 0) {
      alert('Tu carrito está vacío. Agrega al menos un producto antes de comprar.')
      return
    }
    alert('¡Compra realizada con éxito! Gracias por tu preferencia en Veterinaria San Marcos.')
    vaciarCarrito()
  }

  return (
    <aside className="columna-resumen">
      <div className="caja-resumen">
        <h3>Resumen de Compra</h3>
        <div className="linea-total">
          <span>Total a pagar:</span>
          <strong>{formatearPrecio(total)}</strong>
        </div>
        <Boton clase="boton btn-comprar" onClick={finalizarCompra}>Finalizar Compra</Boton>
        <Link to="/productos" className="enlace-volver">← Volver al catálogo</Link>
      </div>
    </aside>
  )
}

export default ResumenCompra
