//columna izquierda del carrito (un producto por tarjeta, con cantidad y botón para quitarlo)
import { Link } from 'react-router-dom'
import TarjetaHorizontal from '../molecules/TarjetaHorizontal'
import Boton from '../atoms/Boton'
import { useTienda } from '../../context/TiendaContext'

function ListaCarrito() {
  const { carrito, productos, cambiarCantidadProducto, quitarProductoDelCarrito } = useTienda()

  // une cada item del carrito con los datos de su producto
  const items = carrito
    .map((item) => ({ producto: productos.find((p) => p.id === item.id), cantidad: item.cantidad }))
    .filter((item) => item.producto)

  return (
    <section className="columna-productos">
      <h2>Productos Seleccionados</h2>

      {items.length === 0 && (
        <p className="sin-resultados">Tu carrito está vacío. <Link to="/productos">Ver productos</Link></p>
      )}

      {items.map(({ producto, cantidad }) => (
        <TarjetaHorizontal key={producto.id} producto={producto}>
          <div className="control-cantidad">
            <button type="button" onClick={() => cambiarCantidadProducto(producto.id, -1)}>-</button>
            <span className="cantidad">{cantidad}</span>
            <button type="button" onClick={() => cambiarCantidadProducto(producto.id, 1)}>+</button>
          </div>
          <Boton clase="boton-ver boton-quitar" onClick={() => quitarProductoDelCarrito(producto.id)}>
            Quitar del carrito
          </Boton>
        </TarjetaHorizontal>
      ))}
    </section>
  )
}

export default ListaCarrito
