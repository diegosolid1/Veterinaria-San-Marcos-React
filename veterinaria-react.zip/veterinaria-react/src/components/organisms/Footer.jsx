//pie de página con tres columnas 
import { Link } from 'react-router-dom'

function Footer() {
  return (
    <footer id="sobre_nosotros">
      <div className="contenedor-footer">
        <div className="columna-footer">
          <h3>Veterinaria San Marcos</h3>
          <p>Atención médica profesional y cuidada para tus mascotas desde 2009.</p>
          <p>Puente Alto, Region Metropolitana</p>
        </div>

        <div className="columna-footer">
          <h4>Navegación</h4>
          <ul>
            <li><Link to="/">Inicio</Link></li>
            <li><Link to="/productos">Productos</Link></li>
            <li><Link to="/registro">Registrate</Link></li>
            <li><Link to="/login">Ingresa</Link></li>
          </ul>
        </div>

        <div className="columna-footer">
          <h4>Horarios y Contacto</h4>
          <p><strong>Lunes a Viernes:</strong> 09:00 - 19:00 hrs</p>
          <p><strong>Sábados:</strong> 10:00 - 14:00 hrs</p>
          <p>Consultas y Urgencias</p>
        </div>
      </div>

      <div className="copyright">
        <p>&copy; 2026 Veterinaria San Marcos. Todos los derechos reservados.</p>
      </div>
    </footer>
  )
}

export default Footer
