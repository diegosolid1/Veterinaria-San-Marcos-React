//sección de presentación de la página de inicio
import { Link } from 'react-router-dom'
import fachada from '../../assets/img/VETERINARIA.jpg'
import video from '../../assets/video/perros_jugando.mp4'

function Presentacion() {
  return (
    <section className="presentacion" id="presentacion">
      <h2>Cuidamos a tu mascota con dedicación</h2>
      <p>
        Desde 2009 en Rancagua, brindamos atención integral para perros, gatos, conejos y aves.
        Contamos con médicos veterinarios expertos listos para ayudar a tu mejor amigo.
      </p>
      <img src={fachada} alt="Fachada de Veterinaria San Marcos" width="550" />
      <br /><br />
      <h2>video informativo! </h2>
      <iframe width="560" height="315" src={video} title="Video de presentación" frameBorder="0" allowFullScreen></iframe>
      <br /><br />
      <Link to="/productos" className="boton">Agendar / Ver Servicios</Link>
    </section>
  )
}

export default Presentacion
