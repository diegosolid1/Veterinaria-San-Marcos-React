//lista de tarjetas que recibe los productos ya filtrados
import TarjetaProducto from '../molecules/TarjetaProducto'

function GaleriaProductos({ productos }) {
  return (
    <div className="contenedor-tarjetas">
      {productos.length === 0 && <p className="sin-resultados">No se encontraron productos con esos filtros.</p>}
      {productos.map((producto) => (
        <TarjetaProducto key={producto.id} producto={producto} />
      ))}
    </div>
  )
}

export default GaleriaProductos
