// usuario para el login. Los que se crean en Registro se guardan en localStorage
const usuariosFijos = [
  {
    nombre: 'Administrador',
    apellido: 'San Marcos',
    telefono: '+56912345678',
    correo: 'admin@duocuc.cl',
    clave: 'admin123',
    rol: 'admin'
  }
]

export default usuariosFijos
