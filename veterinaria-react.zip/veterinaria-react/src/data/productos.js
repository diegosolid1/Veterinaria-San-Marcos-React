import imgBiofresh from '../assets/img/BiofreshGatitos.png'
import imgVitalcan from '../assets/img/VitalcanPerroAdulto.png'
import imgRevolution from '../assets/img/GatoPipeta.jpg'
import imgAdvantix from '../assets/img/PerroPipeta.jpg'
import imgArtriofin from '../assets/img/AnalgesicoPerro.jpg'
import imgConsulta from '../assets/img/VETERINARIA.jpg'

// Catálogo inicial de la veterinaria.
// Lo usan Productos, Producto, Carrito y el Panel de Control.
export const categorias = ['Alimento', 'Antiparasitario', 'Medicamento', 'Servicio']
export const especies = ['Perro', 'Gato', 'Todas']

const productos = [
  {
    id: 1,
    nombre: 'BIOFRESH – NATURAL GATITOS 1,5 KG',
    descripcion:
      'El Biofresh Gatito 1,5 kg es un alimento Super Premium natural diseñado especialmente para cubrir las altas demandas nutricionales de los gatitos desde el destete hasta los 12 meses de edad. Su fórmula contiene carnes frescas de pollo y salmón, frutas, verduras y hierbas naturales, con un perfil grain-free (libre de cereales y gluten) para una digestión suave y una absorción superior. Rico en proteínas de alta calidad, grasas saludables, DHA, EPA, taurina y antioxidantes naturales, este alimento favorece un desarrollo equilibrado, fortalece el sistema inmune, cuida la salud intestinal y potencia el crecimiento saludable del pelaje, huesos y músculos.',
    precio: 19700,
    imagen: imgBiofresh,
    categoria: 'Alimento',
    especie: 'Gato'
  },
  {
    id: 2,
    nombre: 'Vitalcan Premium Perro Adulto Carne 20 kg',
    descripcion:
      'Vitalcan Premium Perro Adulto 20 kg es un alimento completo y balanceado diseñado para cubrir las necesidades nutricionales específicas de los perros adultos. Su fórmula aporta energía sostenida, proteína de alta calidad y nutrientes funcionales que promueven la digestión saludable, fortalecen el sistema inmune y mejoran visiblemente la salud de la piel y el brillo del pelaje.',
    precio: 38690,
    imagen: imgVitalcan,
    categoria: 'Alimento',
    especie: 'Perro'
  },
  {
    id: 3,
    nombre: 'Antiparasitario para Gato Pipeta Revolution Plus 1,0 mL 5 a 10 kg',
    descripcion:
      'Revolution Plus Gato 5 - 10 kg es un antiparasitario de amplio espectro desarrollado por Zoetis que combina selamectina y sarolaner para proporcionar protección simultánea frente a pulgas, garrapatas, ácaros, piojos, algunos parásitos intestinales y la enfermedad del gusano del corazón. Su formulación permite controlar múltiples tipos de parásitos mediante una sola aplicación mensual. Esta presentación contiene 1 pipeta de 1 ml, equivalente a 1 mes completo de protección. Es una excelente alternativa para tutores que desean iniciar un protocolo antiparasitario, realizar una protección puntual o evaluar la respuesta del gato antes de adquirir formatos de mayor duración. Si tu gato pesa entre 5 y 10 kg y requiere una protección integral frente a parásitos internos y externos, Revolution Plus ofrece una solución práctica y completa en una sola aplicación mensual, ayudando a simplificar el manejo preventivo y reduciendo la necesidad de utilizar varios productos distintos.',
    precio: 12490,
    imagen: imgRevolution,
    categoria: 'Antiparasitario',
    especie: 'Gato'
  },
  {
    id: 4,
    nombre: 'Advantix 10-25 Kg',
    descripcion:
      'advantix®: Apoyo funcional para la protección externa de tu perro. Advantix®, la pipeta experta en leishmaniosis, es un antiparasitario externo para perros formulado con dos sustancias activas, imidacloprid y permetrina, que actúan de forma combinada constituyendo una amplia cobertura frente a pulgas, garrapatas, flebotomos, mosquitos, piojos y moscas de los establos para proteger a tu perro como se merece.',
    precio: 9490,
    imagen: imgAdvantix,
    categoria: 'Antiparasitario',
    especie: 'Perro'
  },
  {
    id: 5,
    nombre: 'Artriofin 88 Mg 10 Comprimidos',
    descripcion:
      'Artriofin es indicado en el alivio del dolor e inflamación asociada a cuadros osteoarticulares agudos o crónicos, tales como la osteoartritis canina. Su uso también se recomienda en el control del dolor post operatorio asociado a cirugías ortopédicas y de tejidos blandos.',
    precio: 12690,
    imagen: imgArtriofin,
    categoria: 'Medicamento',
    especie: 'Perro'
  },
  {
    id: 6,
    nombre: 'Consulta Veterinaria',
    descripcion: 'Consulta Veterinaria General',
    precio: 9000,
    imagen: imgConsulta,
    categoria: 'Servicio',
    especie: 'Todas'
  }
]

export default productos
