# Plan de pruebas – Veterinaria San Marcos (React)

**Herramienta:** Vitest (`npm test`). Archivos en `src/tests/`.
**Patrón:** AAA (Arrange: preparar datos, Act: ejecutar, Assert: comprobar).
**Estado:** todas las pruebas se ejecutaron con `npm test` y **Pasan**.

## 1. Pruebas unitarias (Vitest) – 16 pruebas

| ID | Componente (describe) | Caso de prueba (it) | Preparación (Arrange) | Acción (Act) | Resultado esperado (Assert) | Estado |
|---|---|---|---|---|---|---|
| PU-01 | Validaciones | Acepta un correo con dominio permitido | `cliente@gmail.com` | `validarCorreo(correo)` | Devuelve `''` | Pasa |
| PU-02 | Validaciones | Rechaza teléfono sin +56 | `912345678` | `validarTelefono(telefono)` | Devuelve un mensaje de error | Pasa |
| PU-03 | Validaciones | Registro completo (con datos de la mascota) | Objeto con los 10 campos válidos | `validarRegistro(datos)` | Devuelve `{}` | Pasa |
| PU-04 | Validaciones | Producto con precio negativo | Producto con precio `-5` | `validarProducto(datos)` | `errores.precio` = "El precio debe ser mayor a 0." | Pasa |
| PU-05 | Carrito | Agregar producto nuevo | Carrito `[]` | `agregarAlCarrito(carrito, 1)` | `[{ id: 1, cantidad: 1 }]` | Pasa |
| PU-06 | Carrito | Agregar producto que ya estaba | Producto 1 con cantidad 2 | `agregarAlCarrito(carrito, 1)` | Cantidad 3 | Pasa |
| PU-07 | Carrito | Restar cuando la cantidad es 1 | Producto 1 con cantidad 1 | `cambiarCantidad(carrito, 1, -1)` | Carrito vacío | Pasa |
| PU-08 | Carrito | Total del carrito | Productos de $10.000 y $5.000, cantidades 2 y 3 | `calcularTotal(carrito, productos)` | 35000 | Pasa |
| PU-09 | Catálogo | Filtrar por texto | 3 productos, texto `advantix` | `filtrarProductos(...)` | Solo Advantix | Pasa |
| PU-10 | Catálogo | Solo favoritos | 3 productos, favorito `[3]` | `filtrarProductos(...)` con `soloFavoritos` | Solo el producto 3 | Pasa |
| PU-11 | Catálogo | Alternar favorito | Favoritos `[]` | `alternarFavorito` dos veces con id 2 | `[2]` y luego `[]` | Pasa |
| PU-12 | CRUD | Crear producto | 3 productos + uno nuevo | `agregarProducto(productos, nuevo)` | 4 productos, el nuevo con id 4 | Pasa |
| PU-13 | CRUD | Editar producto | 3 productos | `editarProducto(productos, 2, { precio: 12000 })` | El producto 2 tiene precio 12000 y los demás no cambian | Pasa |
| PU-14 | CRUD | Eliminar producto | 3 productos | `eliminarProducto(productos, 1)` | Quedan 2, sin el id 1 | Pasa |
| PU-15 | Sesión | Credenciales correctas | Lista con el admin | `buscarUsuario('admin@duocuc.cl', 'admin123', usuarios)` | Usuario con rol `admin` | Pasa |
| PU-16 | Sesión | Contraseña incorrecta | Lista con el admin | `buscarUsuario('admin@duocuc.cl', 'otraClave', usuarios)` | `null` | Pasa |

## 2. Qué se evalúa

| Funcionalidad | Archivos críticos | Pruebas |
|---|---|---|
| Validaciones y campos de la veterinaria | `utils/validaciones.js`, `hooks/useFormulario.js`, formularios | PU-01 a PU-04 |
| Carrito | `utils/tienda.js`, `ListaCarrito`, `ResumenCompra` | PU-05 a PU-08 |
| Filtros y favoritos | `utils/tienda.js`, `FiltroProductos`, `BotonFavorito` | PU-09 a PU-11 |
| CRUD en memoria | `utils/tienda.js`, `Admin`, `FormularioProducto` | PU-12 a PU-14 |
| Sesión y rutas privadas | `utils/tienda.js`, `RutaPrivada`, `TiendaContext` | PU-15, PU-16 |

**Resultado:** 16 de 16 pruebas en estado **Pasa**.
